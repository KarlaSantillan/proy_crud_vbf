proyecto vistas badas en clases
